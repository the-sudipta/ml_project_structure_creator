# ML Project Structure Creator

This is a Python script that creates a machine learning project structure with basic data processing files.

## Installation

You can install this package using pip:

```bash
pip install ml_project_structure_creator
